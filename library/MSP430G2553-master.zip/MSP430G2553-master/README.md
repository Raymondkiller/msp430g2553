# MSP430G2553
This is all of my embedded libraries, examples, module testings, and projects correlating to [MSP430G2553] micro-controller.